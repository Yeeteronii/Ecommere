<?php
$path = $_SERVER['SCRIPT_NAME'];
?>

<html>
    <head>
        <title>Office List</title>

        <?php require_once dirname(__DIR__) . "/scripts.php"; ?>
    </head>
    <body>
		<div class="container">
		<?php require_once dirname(__DIR__) . "/nav.php"; ?>
        <table class="table table-striped">
			<thead>
            <tr>
                <th>Office Code</th>
                <th>Phone</th>
                <th>Address</th>
                <th>City</th>
                <th>State/Territory</th>
                <th>Country</th>
                <th>Postal Code</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
                <?php
                
                ?>
			</tbody>
        </table>
		</div>
    </body>
</html>