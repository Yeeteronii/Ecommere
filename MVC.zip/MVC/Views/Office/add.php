<?php
$path = $_SERVER['SCRIPT_NAME'];
?>
<html>
    <head>
        <title>Profile</title>
		<style>
			label{
				display: inline-block;
				width: 150px;
			}
			input[type='button']{
				width: 150px;
			}
		</style>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
		<div class="container">
		<?php include_once dirname(__DIR__) . "/nav.php"; ?>
			<form action="" method="POST">
	            <br><label>City</label><input name="city" value="" >
	            <br><label>Phone</label><input name="phone" value="" >
	            <br><label>Address Line 1</label><input name="addressLine1" value="" >
	            <br><label>Address Line 2</label><input name="addressLine2" value="" >
	            <br><label>State</label><input name="state" value="" >
	            <br><label>Country</label><input name="country" value="" >
	            <br><label>Postal Code</label><input name="postalCode" value="" >
	            <br><label>Territory</label><input name="territory" value="" >
	            <br><input type="submit"name="" value="Add Office">
            </form>

            <br>
		</div>
    </body>
</html>