<?php
$path = $_SERVER['SCRIPT_NAME'];
?>

<html>
    <head>
        <title>Office List</title>
        <style type="text/css">
            img.icons{
                width: 24px;
            }
        </style>

        <?php require_once dirname(__DIR__) . "/scripts.php"; ?>
    </head>
    <body>
		<div class="container">
		<?php require_once dirname(__DIR__) . "/nav.php"; ?>
        <table class="table table-striped">
			<thead>
            <tr>
                <th>Office Code</th>
                <th>Phone</th>
                <th>Address</th>
                <th>City</th>
                <th>State/Territory</th>
                <th>Country</th>
                <th>Postal Code</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
                <?php
                    foreach($data as $row) {
                ?>
                <tr>
                    <td><?=$row->officeCode;?></td>
                    <td><?=$row->phone;?></td>
                    <td><?=$row->addressLine1 . "<br>" . $row->addressLine2;?></td>
                    <td><?=$row->city;?></td>
                    <td><?=$row->state;?></td>
                    <td><?=$row->country;?></td>
                    <td><?=$row->postalCode;?></td>
                    <?php 
                        $urlView = "/MVC/MVC/office/view/" . $row->officeCode; 
                        $urlUpdate = "/MVC/MVC/office/update/" . $row->officeCode; 
                        $urlDelete = "/MVC/MVC/office/delete/" . $row->officeCode; 
                    ?>
                    <td>
                        <a href="<?=$urlView;?>"><img class="icons" src="<?=dirname($path);?>/images/view.png"></a>
                        <a href="<?=$urlUpdate;?>"><img class="icons" src="<?=dirname($path);?>/images/update.png"></a>
                        <a href="<?=$urlDelete;?>"><img class="icons" src="<?=dirname($path);?>/images/delete.png"></a>
                    </td>
                </tr>
                <!--
                        echo "<tr>";
                            echo "<td>".$row->officeCode."</td>";
                            echo "<td>".$row->phone."</td>";
                            echo "<td>".$row->addressLine1 . "<br>" . $row->addressLine2 ."</td>";
                            echo "<td>".$row->city."</td>";
                            echo "<td>".$row->state."</td>";
                            echo "<td>".$row->country."</td>";
                            echo "<td>".$row->postalCode."</td>";
                        echo "</tr>";
                    -->
                <?php
                    }
                ?>
			</tbody>
        </table>
        <a href="<?php echo dirname($path);?>/office/add"><input type="button" name="" value="Add a new Office">
		</div>
    </body>
</html>