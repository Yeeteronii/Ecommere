<?php

$controller = (isset($_GET['controller'])) ? $_GET['controller'] : "office";


$controllerClassName = ucfirst($controller) . "Controller";
include_once "Controllers/$controllerClassName.php";

$ct = new $controllerClassName();
$ct->route();
