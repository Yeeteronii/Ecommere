<?php

include_once "Models/Office.php";
include_once "Controllers/Controller.php";

class OfficeController extends Controller{

	function route(){

		$action = isset($_GET['action']) ? $_GET['action'] : "list"   ;
		$id = isset($_GET['id']) ? intval($_GET['id']) : -1;
		
        if($action == "list"){
            // get all Offices
            $offices = Office::list();
            $this->render("Office", "list", $offices);
        }
        else if($action == "updateSave"){
			$office = new Office($_POST['officeCode']);
			$office->update($_POST);
			header("Location: /office");
        }
        else{
            $office = new Office($id);
            $this->render("Office", $action, array($office));
        }

	}

}

?>