<?php

include_once "Models/Model.php";

class Office extends Model{

    public $officeCode;
    public $city;
    public $phone;
    public $addressLine1;
    public $addressLine2;
    public $state;
    public $country;
    public $postalCode;
    public $territory;


    function __construct($param = null){
        if(is_object($param)){
            $this->setProperties($param);
        }
        elseif(is_int($param)) {
            $conn = Model::connect();
            $sql = "SELECT * FROM `offices` WHERE `officeCode` = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", ($param));
            $stmt->execute();

            $result = $stmt->get_result();
            $row = $result->fetch_object();
            $this->setProperties($row);

        }
    }

    private function setProperties($param) {
        // if (is_object($param)) {
            $this->officeCode = $param->officeCode;
            $this->city = $param->city;
            $this->phone = $param->phone;
            $this->addressLine1 = $param->addressLine1;
            $this->addressLine2 = $param->addressLine2;
            $this->state = $param->state;
            $this->country = $param->country;
            $this->postalCode = $param->postalCode;
            $this->territory = $param->territory;
        // }
        // elseif(is_array($param)){
        //     $this->officeCode = $param['officeCode'];
        //     $this->city = $param['city'];
        //     $this->phone = $param['phone'];
        //     $this->addressLine1 = $param['addressLine1'];
        //     $this->addressLine2 = $param['addressLine2'];
        //     $this->state = $param['state'];
        //     $this->country = $param['country'];
        //     $this->postalCode = $param['postalCode'];
        //     $this->territory = $param['territory'];
        // }

    }

    public static function list(){
        $list = [];
        $sql = "SELECT * FROM `offices` WHERE isActive = 1";

        $connection = Model::connect();
        $result = $connection->query($sql);

        while($row = $result->fetch_object()){
            $office = new Office($row);
            array_push($list, $office);
        }

        return $list;
    }

    public static function view($officeCode=-1){
        $list = [];
        $sql = "SELECT * FROM `offices` WHERE `officeCode` = '" . $officeCode . "' LIMIT 1;";

        $connection = Model::connect();
        $result = $connection->query($sql);

        $row = $result->fetch_object();
        $office = new Office($row);
        array_push($list, $office);

        return $list;
    }

    public function add($data) {
        $conn = Model::connect();
        $sql = "INSERT INTO `offices` (`officeCode`, `city`, `phone`, `addressLine1`, `addressLine2`, `state`, `country`, `postalCode`, `territory`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?);";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", 
            $_POST['city'],$_POST['phone'],$_POST['addressLine1'],$_POST['addressLine2'],$_POST['state'],$_POST['country'],$_POST['postalCode'],$_POST['territory']);
            $stmt->execute();
    }

    public function delete() {
        $this->deactivate();
        //$this->permanentDelete();
    }

    private function deactivate() {
        $conn = Model::connect();
        $sql = "UPDATE `offices` SET `isActive` = 0 WHERE `offices`. `officeCode` = ?;";
        $stmt = $conn -> prepare($sql);
        $stmt->bind_param("i", $this->officeCode);
        $stmt->execute();
    }

    private function permanentDelete() {

    }
    public function update($newData) {
        $conn = Model::connect();
        // $this->setProperties($_POST);
        $sql = "UPDATE `offices` SET `city` = ?, `phone` = ? , `addressLine1` = ?, `addressLine2` = ?, `state` = ?, `country` = ?, `postalCode` = ?, `territory` = ? WHERE `offices`.`officeCode` = ?;";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssi", $newData['city'], $newData['phone'], $newData['addressLine1'], $newData['addressLine2'], $newData['state'], $newData['country'], $newData['postalCode'], $newData['territory'], $this->officeCode);
        $stmt->execute();
    }
}
?>