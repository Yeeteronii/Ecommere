<?php

$controller = (isset($_GET['controller'])) ? $_GET['controller'] : "home";
$action = (isset($_GET['action'])) ? $_GET['action'] : "list";
$id = (isset($_GET['id'])) ? intval($_GET['id']) : -1;

/*
var_dump($controller);
var_dump($action);
var_dump($id);
//*/

$controllerClassName = ucfirst($controller) . "Controller";
//var_dump($controllerClassName);
include_once "Controllers/$controllerClassName.php";

//*
$ct = new $controllerClassName();
$ct->route();
//*/