<?php
include_once "Controllers/Controller.php";
include_once "Models/Office.php";

class OfficeController extends Controller{

	function route(){
		$path = $_SERVER['SCRIPT_NAME'];
		$action = isset($_GET['action']) ? $_GET['action'] : "list";
		$id = isset($_GET['id']) ? intval($_GET['id']) : -1;

		if($action == "list"){
			$data = Office::list();
			$this->render("Office", "list", $data);
		}
		elseif($action == "add"){
			if(empty($_POST)) {
				$this->render("Office", "add");
			} else {
				$o = new Office(); 
				$o->add($_POST);
				$newUrl = dirname($path) . "/office/list";
				header("Location: " .$newUrl);
			}
		}
		elseif($action == "view"){
			$data = Office::view($id);
			$this->render("Office", "view", $data);
		}
		elseif($action == "update"){
			$o = new Office($id);
			if (empty($_POST['officeCode'])) {
				$arr = [];
				array_push($arr, $o);
				$this->render("Office", "update", $arr);
			} else {
				$o->update($_POST);
				$newUrl = dirname($path) . "/office/list";
				header("Location: " .$newUrl);
			}
		}
		elseif($action == "delete"){
			//Deactivate Object
			$o = new Office($id);
			$o->delete();
			$newUrl = dirname($path) . "/office/list";
			header('Location: ' .$newUrl);
		}
		else{

		}
	}

}

?>