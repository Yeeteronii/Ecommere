<?php
$path = $_SERVER['SCRIPT_NAME'];
?>
<html>
    <head>
        <title>Profile</title>
		<style>
			label{
				display: inline-block;
				width: 150px;
			}
			input[type='button']{
				width: 150px;
			}
		</style>

		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
		<div class="container">
		<?php include_once dirname(__DIR__) . "/nav.php"; ?>

            <br><label>Office Code</label><input name="officeCode" value="<?php echo $data[0]->officeCode;?>" disabled>
            <br><label>City</label><input name="city" value="<?php echo $data[0]->city;?>" disabled>
            <br><label>Phone</label><input name="phone" value="<?php echo $data[0]->phone;?>" disabled>
            <br><label>Address Line 1</label><input name="addressLine1" value="<?php echo $data[0]->addressLine1;?>" disabled>
            <br><label>Address Line 2</label><input name="addressLine2" value="<?php echo $data[0]->addressLine2;?>" disabled>
            <br><label>State</label><input name="state" value="<?php echo $data[0]->state;?>" disabled>
            <br><label>Country</label><input name="country" value="<?php echo $data[0]->country;?>" disabled>
            <br><label>Postal Code</label><input name="postalCode" value="<?php echo $data[0]->postalCode;?>" disabled>
            <br><label>Territory</label><input name="territory" value="<?php echo $data[0]->territory;?>" disabled>

            <br><a href="<?php echo $path;?>?controller=office"><input type="button" value="Go to Office list"></a>
            <a href="<?php echo $path;?>?controller=office&action=update&id=<?php echo $data[0]->officeCode;?>"><input type="button" value="Modify"></a>
		
		</div>
    </body>
</html>