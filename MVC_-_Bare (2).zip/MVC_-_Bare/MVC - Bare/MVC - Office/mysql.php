<?php


$server = "localhost";
$user = "root";
$pass = "";
$db = "classicmodels";

$conn = new mysqli($server, $user, $pass, $db);

if($conn->connect_error){
	die("Connection error! I can't deal with this anymore<br>" . $conn->connect_error);
}

