<?php

include_once dirname(__DIR__) . "/mysql.php";

class Office{

    public $officeCode;
    public $city;
    public $phone;
    public $addressLine1;
    public $addressLine2;
    public $state;
    public $country;
    public $postalCode;
    public $territory;


    function __construct($id = -1){
        global $conn;

        $this->officeCode = $id;
        if($id < 0){
            $this->city = "";
            $this->phone = "";
            $this->addressLine1 = "";
            $this->addressLine2 = "";
            $this->state = "";
            $this->country = "";
            $this->postalCode = "";
            $this->territory = "";
        }
        else{
            $sql = "SELECT * from `offices` WHERE `officeCode`=" . $id;

            $result = $conn->query($sql);

            $data = $result->fetch_assoc();

            $this->officeCode = $id;
            $this->city = $data['city'];
            $this->phone = $data['phone'];
            $this->addressLine1 = $data['addressLine1'];
            $this->addressLine2 = $data['addressLine2'];
            $this->state = $data['state'];
            $this->country = $data['country'];
            $this->postalCode = $data['postalCode'];
            $this->territory = $data['territory'];
        }
    }


    public static function list(){
        global $conn;
        $list = array();

        $sql = "SELECT * from `offices`";
        $result = $conn->query($sql);

        while($row = $result->fetch_assoc()){
            $off = new Office();
            $off->officeCode = $row['officeCode'];
            $off->city = $row['city'];
            $off->phone = $row['phone'];
            $off->addressLine1 = $row['addressLine1'];
            $off->addressLine2 = $row['addressLine2'];
            $off->state = $row['state'];
            $off->country = $row['country'];
            $off->postalCode = $row['postalCode'];
            $off->territory = $row['territory'];


            array_push($list, $off);
        }

        return $list;
    }

    function update($data){
        global $conn;

		$officeCode = $data['officeCode'];
		$city = $data['city'];
		$phone = $data['phone'];
		$addressLine1 = $data['addressLine1'];
		$addressLine2 = $data['addressLine2'];
		$state = $data['state'];
		$country = $data['country'];
		$postalCode = $data['postalCode'];
		$territory = $data['territory'];

        $sql = "UPDATE `offices` SET `city` = '$city', `phone` = '$phone', `addressLine1` = '$addressLine1', `addressLine2` = '$addressLine2', `state` = '$state', `country` = '$country', `postalCode` = '$postalCode', `territory` = '$territory' WHERE `offices`.`officeCode` = $officeCode;";

        $conn->query($sql);

        var_dump($conn->error);
    }

}

?>